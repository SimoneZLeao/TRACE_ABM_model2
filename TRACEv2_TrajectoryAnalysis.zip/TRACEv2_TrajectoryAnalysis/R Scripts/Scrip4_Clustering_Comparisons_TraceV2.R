# ==================================================
# ArtistCareerTrajectory
# Script 04B: Compare Trajectory Clusters
# Simulation 1 — TRACE v2
#
# Compare k = 4, 5 and 6
# 260-week simulation
# Exit and return are possible
#
# Clusters are determined ONLY from OM distances.
# Other variables are used to CHARACTERISE
# the resulting trajectory clusters.
# ==================================================


# ==================================================
# Load libraries
# ==================================================

library(readr)
library(dplyr)


# ==================================================
# Read trajectory characteristics
# ==================================================

trajectory_characteristics <- read_csv(
  "outputR/Sim1_tracev2_trajectory_characteristics_complete.csv",
  show_col_types = FALSE
)


# ==================================================
# Check trajectory characteristics
# ==================================================

cat("\n")
cat("=============================================\n")
cat("TRAJECTORY CHARACTERISTICS\n")
cat("=============================================\n")

print(names(trajectory_characteristics))


# ==================================================
# Check required variables
# ==================================================

required_variables <- c(
  "ArtistID",
  "Sequence",
  "Transitions",
  "Turbulence",
  "Entropy",
  "FinalEC",
  "FinalSC",
  "FinalSR",
  "SecondaryJobs",
  "MeanSecondaryJobHours",
  "MeanArtisticHours",
  "ExitCount",
  "ReturnCount",
  "ExitTick",
  "FinalSurvivor"
)

missing_variables <- setdiff(
  required_variables,
  names(trajectory_characteristics)
)

if (length(missing_variables) > 0) {
  
  stop(
    paste(
      "The following required variables are missing:",
      paste(missing_variables, collapse = ", ")
    )
  )
}


# ==================================================
# Read OM distance matrix
# ==================================================

OM_distance <- readRDS(
  "outputR/Sim1_tracev2_OM_distance.rds"
)


# ==================================================
# Convert to distance object
# ==================================================

OM_dist <- as.dist(OM_distance)


# ==================================================
# Convert distance object to matrix
# ==================================================

OM_matrix <- as.matrix(OM_dist)


# ==================================================
# Check OM / trajectory dimensions
# ==================================================

cat("\n")
cat("=============================================\n")
cat("OM / TRAJECTORY CHECK\n")
cat("=============================================\n")

cat(
  "Number of trajectories:",
  nrow(trajectory_characteristics),
  "\n"
)

cat(
  "Number of OM trajectories:",
  nrow(OM_matrix),
  "\n"
)

if (
  nrow(trajectory_characteristics) != nrow(OM_matrix)
) {
  
  stop(
    "The number of trajectory records does not match the OM distance matrix."
  )
}


# ==================================================
# Hierarchical clustering
# ==================================================

trajectory_hclust <- hclust(
  OM_dist,
  method = "ward.D2"
)


# ==================================================
# Define cluster solutions to compare
# ==================================================

k_values <- c(4, 5, 6)


# ==================================================
# Create empty result objects
# ==================================================

cluster_size_results <- data.frame()

cluster_characteristic_results <- data.frame()

cluster_separation_results <- data.frame()


# ==================================================
# Run comparison for k = 4, 5 and 6
# ==================================================

for (k in k_values) {
  
  
  # ==================================================
  # Cut dendrogram
  # ==================================================
  
  cluster_assignment <- cutree(
    trajectory_hclust,
    k = k
  )
  
  
  # ==================================================
  # Create cluster membership table
  # ==================================================
  
  cluster_membership <- data.frame(
    
    ArtistID = as.numeric(
      names(cluster_assignment)
    ),
    
    Cluster = as.numeric(
      cluster_assignment
    )
    
  )
  
  
  # ==================================================
  # Cluster sizes
  # ==================================================
  
  cluster_sizes <- table(
    cluster_assignment
  )
  
  
  temp_sizes <- data.frame(
    
    k = k,
    
    Cluster = as.numeric(
      names(cluster_sizes)
    ),
    
    N = as.numeric(
      cluster_sizes
    )
    
  ) %>%
    
    mutate(
      
      Percentage =
        100 * N / sum(N)
      
    )
  
  
  cluster_size_results <- bind_rows(
    
    cluster_size_results,
    
    temp_sizes
    
  )
  
  
  # ==================================================
  # Join cluster membership
  # ==================================================
  
  trajectory_clusters <- trajectory_characteristics %>%
    
    left_join(
      cluster_membership,
      by = "ArtistID"
    )
  
  
  # ==================================================
  # Check cluster assignments
  # ==================================================
  
  if (
    any(
      is.na(
        trajectory_clusters$Cluster
      )
    )
  ) {
    
    stop(
      paste(
        "Missing cluster assignments for k =",
        k
      )
    )
    
  }
  
  
  # ==================================================
  # Cluster characteristics
  # ==================================================
  
  temp_characteristics <-
    trajectory_clusters %>%
    
    group_by(
      Cluster
    ) %>%
    
    summarise(
      
      # ------------------------------------------------
      # Cluster size
      # ------------------------------------------------
      
      N = n(),
      
      
      # ------------------------------------------------
      # TRAJECTORY DYNAMICS
      # ------------------------------------------------
      
      MeanTransitions =
        mean(
          Transitions,
          na.rm = TRUE
        ),
      
      SDTransitions =
        sd(
          Transitions,
          na.rm = TRUE
        ),
      
      MeanTurbulence =
        mean(
          Turbulence,
          na.rm = TRUE
        ),
      
      SDTurbulence =
        sd(
          Turbulence,
          na.rm = TRUE
        ),
      
      MeanEntropy =
        mean(
          Entropy,
          na.rm = TRUE
        ),
      
      SDEntropy =
        sd(
          Entropy,
          na.rm = TRUE
        ),
      
      
      # ------------------------------------------------
      # FIELD RECURRENCE
      # ------------------------------------------------
      
      MeanFirstExitTick =
        mean(
          ExitTick,
          na.rm = TRUE
        ),
      
      SDFirstExitTick =
        sd(
          ExitTick,
          na.rm = TRUE
        ),
      
      MeanExitCount =
        mean(
          ExitCount,
          na.rm = TRUE
        ),
      
      SDExitCount =
        sd(
          ExitCount,
          na.rm = TRUE
        ),
      
      MeanReturnCount =
        mean(
          ReturnCount,
          na.rm = TRUE
        ),
      
      SDReturnCount =
        sd(
          ReturnCount,
          na.rm = TRUE
        ),
      
      ArtistsWithReturns =
        sum(
          ReturnCount > 0,
          na.rm = TRUE
        ),
      
      PercentageWithReturns =
        100 *
        sum(
          ReturnCount > 0,
          na.rm = TRUE
        ) /
        n(),
      
      
      # ------------------------------------------------
      # SECONDARY EMPLOYMENT
      # ------------------------------------------------
      
      MeanSecondaryJobs =
        mean(
          SecondaryJobs,
          na.rm = TRUE
        ),
      
      SDSecondaryJobs =
        sd(
          SecondaryJobs,
          na.rm = TRUE
        ),
      
      ArtistsWithSecondaryJobs =
        sum(
          SecondaryJobs > 0,
          na.rm = TRUE
        ),
      
      PercentageWithSecondaryJobs =
        100 *
        sum(
          SecondaryJobs > 0,
          na.rm = TRUE
        ) /
        n(),
      
      MeanSecondaryJobHours =
        mean(
          .data$MeanSecondaryJobHours,
          na.rm = TRUE
        ),
      
      SDSecondaryJobHours =
        sd(
          .data$MeanSecondaryJobHours,
          na.rm = TRUE
        ),
      
      
      # ------------------------------------------------
      # ARTISTIC PRACTICE
      # ------------------------------------------------
      
      MeanArtisticHours =
        mean(
          .data$MeanArtisticHours,
          na.rm = TRUE
        ),
      
      SDArtisticHours =
        sd(
          .data$MeanArtisticHours,
          na.rm = TRUE
        ),
      
      
      # ------------------------------------------------
      # FINAL ECONOMIC CAPITAL
      # ------------------------------------------------
      
      MeanFinalEC =
        mean(
          FinalEC,
          na.rm = TRUE
        ),
      
      SDFinalEC =
        sd(
          FinalEC,
          na.rm = TRUE
        ),
      
      
      # ------------------------------------------------
      # FINAL SOCIAL CAPITAL
      # ------------------------------------------------
      
      MeanFinalSC =
        mean(
          FinalSC,
          na.rm = TRUE
        ),
      
      SDFinalSC =
        sd(
          FinalSC,
          na.rm = TRUE
        ),
      
      
      # ------------------------------------------------
      # FINAL SELF-REALISATION
      # ------------------------------------------------
      
      MeanFinalSR =
        mean(
          FinalSR,
          na.rm = TRUE
        ),
      
      SDFinalSR =
        sd(
          FinalSR,
          na.rm = TRUE
        ),
      
      
      # ------------------------------------------------
      # FINAL SURVIVAL
      # ------------------------------------------------
      
      Survivors =
        sum(
          FinalSurvivor,
          na.rm = TRUE
        ),
      
      PercentageSurvivors =
        100 *
        sum(
          FinalSurvivor,
          na.rm = TRUE
        ) /
        n(),
      
      .groups = "drop"
      
    ) %>%
    
    mutate(
      k = k
    ) %>%
    
    select(
      k,
      everything()
    )
  
  
  cluster_characteristic_results <-
    bind_rows(
      cluster_characteristic_results,
      temp_characteristics
    )
  
  
  # ==================================================
  # Calculate within-cluster OM distance
  # ==================================================
  
  for (
    cluster_number in sort(
      unique(
        cluster_assignment
      )
    )
  ) {
    
    
    members <- names(
      cluster_assignment[
        cluster_assignment ==
          cluster_number
      ]
    )
    
    
    if (
      length(members) > 1
    ) {
      
      cluster_distances <-
        OM_matrix[
          members,
          members
        ]
      
      mean_within_distance <-
        mean(
          cluster_distances[
            upper.tri(
              cluster_distances
            )
          ],
          na.rm = TRUE
        )
      
    } else {
      
      mean_within_distance <- NA
      
    }
    
    
    cluster_separation_results <-
      bind_rows(
        
        cluster_separation_results,
        
        data.frame(
          
          k = k,
          
          Cluster = cluster_number,
          
          MeanWithinClusterOM =
            mean_within_distance
          
        )
        
      )
    
  }
  
}


# ==================================================
# Display cluster sizes
# ==================================================

cat("\n")
cat("=============================================\n")
cat("CLUSTER SIZES\n")
cat("=============================================\n")

print(
  cluster_size_results
)


# ==================================================
# Display cluster characteristics
# ==================================================

cat("\n")
cat("=============================================\n")
cat("CLUSTER CHARACTERISTICS\n")
cat("=============================================\n")

print(
  cluster_characteristic_results
)


# ==================================================
# Display within-cluster OM distances
# ==================================================

cat("\n")
cat("=============================================\n")
cat("WITHIN-CLUSTER OM DISTANCES\n")
cat("=============================================\n")

print(
  cluster_separation_results
)


# ==================================================
# Overall within-cluster comparison
# ==================================================

overall_within_cluster <-
  cluster_separation_results %>%
  
  group_by(
    k
  ) %>%
  
  summarise(
    
    MeanWithinClusterOM =
      mean(
        MeanWithinClusterOM,
        na.rm = TRUE
      ),
    
    .groups = "drop"
    
  )


# ==================================================
# Minimum cluster size
# ==================================================

minimum_cluster_size <-
  cluster_size_results %>%
  
  group_by(
    k
  ) %>%
  
  summarise(
    
    MinimumClusterSize =
      min(N),
    
    MinimumClusterPercentage =
      min(Percentage),
    
    .groups = "drop"
    
  )


# ==================================================
# Create overall comparison table
# ==================================================

k_comparison <-
  overall_within_cluster %>%
  
  left_join(
    minimum_cluster_size,
    by = "k"
  ) %>%
  
  arrange(
    k
  )


# ==================================================
# Display overall comparison
# ==================================================

cat("\n")
cat("=============================================\n")
cat("OVERALL COMPARISON OF k = 4, 5 AND 6\n")
cat("=============================================\n")

print(
  k_comparison
)


# ==================================================
# View results
# ==================================================

View(
  cluster_size_results
)

View(
  cluster_characteristic_results
)

View(
  cluster_separation_results
)

View(
  k_comparison
)


# ==================================================
# Save cluster sizes
# ==================================================

write.csv(
  cluster_size_results,
  "outputR/Sim1_tracev2_cluster_comparison_sizes.csv",
  row.names = FALSE
)


# ==================================================
# Save cluster characteristics
# ==================================================

write.csv(
  cluster_characteristic_results,
  "outputR/Sim1_tracev2_cluster_comparison_characteristics.csv",
  row.names = FALSE
)


# ==================================================
# Save within-cluster OM distances
# ==================================================

write.csv(
  cluster_separation_results,
  "outputR/Sim1_tracev2_cluster_comparison_distances.csv",
  row.names = FALSE
)


# ==================================================
# Save overall comparison
# ==================================================

write.csv(
  k_comparison,
  "outputR/Sim1_tracev2_cluster_comparison_k4_k5_k6.csv",
  row.names = FALSE
)


# ==================================================
# Completion message
# ==================================================

cat("\n")
cat("=============================================\n")
cat("TRACE v2 CLUSTER COMPARISON COMPLETED\n")
cat("=============================================\n")

cat(
  "Solutions compared: k = 4, 5 and 6\n"
)

cat(
  "Clustering basis: OM trajectory distance only\n"
)

cat(
  "Additional variables: descriptive characteristics only\n"
)

cat("=============================================\n")