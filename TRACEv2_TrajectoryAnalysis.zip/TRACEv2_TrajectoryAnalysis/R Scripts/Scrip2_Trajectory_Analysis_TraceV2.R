# ==================================================
# ArtistCareerTrajectory
# Script 02: Trajectory Characteristics
# ==================================================


# ==================================================
# Load libraries
# ==================================================

library(readr)
library(dplyr)


# ==================================================
# Read data
# ==================================================

simulation_x <- read_csv(
  "outputR/Sim1_tracev2_combined_status.csv"
)

trajectory_characteristics <- read_csv(
  "outputR/Sim1_tracev2_trajectory_characteristics_status.csv"
)


# ==================================================
# Identify final simulation tick
# ==================================================

final_tick <- max(
  simulation_x$Tick,
  na.rm = TRUE
)


# ==================================================
# Check simulation length
# ==================================================

number_of_ticks <- length(
  unique(simulation_x$Tick)
)

expected_ticks <- final_tick + 1

cat(
  "\n=============================================\n",
  "SIMULATION CHECK\n",
  "=============================================\n",
  sep = ""
)

cat(
  "Final tick:",
  final_tick,
  "\n"
)

cat(
  "Number of unique ticks:",
  number_of_ticks,
  "\n"
)

cat(
  "Expected number of ticks:",
  expected_ticks,
  "\n"
)


# ==================================================
# Extract final observation of each trajectory
# ==================================================

final_state <- simulation_x %>%
  
  group_by(ArtistID) %>%
  
  slice_max(
    Tick,
    n = 1,
    with_ties = FALSE
  ) %>%
  
  select(
    ArtistID,
    FinalState = State,
    FinalStatus = Status,
    FinalEC = EC,
    FinalSC = SC,
    FinalSR = SR,
    SecondaryJobs = SecondaryJobCount
  )


# ==================================================
# Calculate mean weekly working hours
# ==================================================

hours_characteristics <- simulation_x %>%
  
  group_by(ArtistID) %>%
  
  summarise(
    
    MeanSecondaryJobHours = mean(
      SecondaryJobHours,
      na.rm = TRUE
    ),
    
    MeanArtisticHours = mean(
      ArtisticHours,
      na.rm = TRUE
    ),
    
    .groups = "drop"
    
  )


# ==================================================
# Calculate exit and return recurrence
# ==================================================

exit_return_characteristics <- simulation_x %>%
  
  arrange(
    ArtistID,
    Tick
  ) %>%
  
  group_by(
    ArtistID
  ) %>%
  
  mutate(
    PreviousState = lag(State)
  ) %>%
  
  summarise(
    
    ExitCount = sum(
      PreviousState == "Active" &
        State == "Exited",
      na.rm = TRUE
    ),
    
    ReturnCount = sum(
      PreviousState == "Exited" &
        State == "Active",
      na.rm = TRUE
    ),
    
    .groups = "drop"
    
  )


# ==================================================
# First exit tick
# ==================================================

exit_tick <- simulation_x %>%
  
  filter(
    Status == "X"
  ) %>%
  
  group_by(
    ArtistID
  ) %>%
  
  summarise(
    ExitTick = min(Tick),
    .groups = "drop"
  )


# ==================================================
# Join trajectory information
# ==================================================

trajectory_characteristics <- trajectory_characteristics %>%
  
  left_join(
    final_state,
    by = "ArtistID"
  ) %>%
  
  left_join(
    hours_characteristics,
    by = "ArtistID"
  ) %>%
  
  left_join(
    exit_return_characteristics,
    by = "ArtistID"
  ) %>%
  
  left_join(
    exit_tick,
    by = "ArtistID"
  )


# ==================================================
# Complete trajectory characteristics
# ==================================================

trajectory_characteristics <- trajectory_characteristics %>%
  
  mutate(
    
    # Artists who never exited are assigned
    # the final simulation tick.
    # Artists who exited retain their FIRST exit tick.
    ExitTick = ifelse(
      is.na(ExitTick),
      final_tick,
      ExitTick
    ),
    
    # TRUE = artist is Active at the end.
    # FALSE = artist is Exited at the end.
    #
    # Artists who exited and later returned
    # are therefore classified as survivors.
    FinalSurvivor = FinalStatus != "X",
    
    # Duration from the beginning of the simulation
    # to the FIRST exit, expressed in ticks.
    CareerDuration = ExitTick + 1,
    
    # Artists without an observed exit or return
    # transition have zero recurrence.
    ExitCount = ifelse(
      is.na(ExitCount),
      0,
      ExitCount
    ),
    
    ReturnCount = ifelse(
      is.na(ReturnCount),
      0,
      ReturnCount
    )
    
  )


# ==================================================
# Check trajectory characteristics
# ==================================================

cat(
  "\n=============================================\n",
  "TRAJECTORY CHARACTERISTICS\n",
  "=============================================\n",
  sep = ""
)

print(
  names(trajectory_characteristics)
)

print(
  head(trajectory_characteristics)
)

print(
  summary(trajectory_characteristics)
)


# ==================================================
# Check final simulation tick
# ==================================================

cat(
  "\n=============================================\n",
  "FINAL SIMULATION TICK\n",
  "=============================================\n",
  sep = ""
)

cat(
  "Final simulation tick:",
  final_tick,
  "\n"
)


# ==================================================
# Check final status
# ==================================================

cat(
  "\n=============================================\n",
  "FINAL STATUS\n",
  "=============================================\n",
  sep = ""
)

print(
  table(
    trajectory_characteristics$FinalStatus
  )
)


# ==================================================
# Check first exit tick
# ==================================================

cat(
  "\n=============================================\n",
  "FIRST EXIT TICK\n",
  "=============================================\n",
  sep = ""
)

print(
  summary(
    trajectory_characteristics$ExitTick
  )
)


# ==================================================
# Check recurrence
# ==================================================

cat(
  "\n=============================================\n",
  "RECURRENCE\n",
  "=============================================\n",
  sep = ""
)

cat(
  "\nExit Count:\n"
)

print(
  summary(
    trajectory_characteristics$ExitCount
  )
)

cat(
  "\nReturn Count:\n"
)

print(
  summary(
    trajectory_characteristics$ReturnCount
  )
)

cat(
  "\nArtists with at least one exit:",
  sum(
    trajectory_characteristics$ExitCount > 0,
    na.rm = TRUE
  ),
  "\n"
)

cat(
  "Artists with at least one return:",
  sum(
    trajectory_characteristics$ReturnCount > 0,
    na.rm = TRUE
  ),
  "\n"
)


# ==================================================
# Check secondary employment
# ==================================================

cat(
  "\n=============================================\n",
  "SECONDARY EMPLOYMENT\n",
  "=============================================\n",
  sep = ""
)

cat(
  "\nNumber of secondary jobs per artist:\n"
)

print(
  summary(
    trajectory_characteristics$SecondaryJobs
  )
)

cat(
  "\nMean weekly secondary-job hours per artist:\n"
)

print(
  summary(
    trajectory_characteristics$MeanSecondaryJobHours
  )
)

cat(
  "\nArtists with at least one secondary job:",
  sum(
    trajectory_characteristics$SecondaryJobs > 0,
    na.rm = TRUE
  ),
  "\n"
)

cat(
  "Artists with no secondary jobs:",
  sum(
    trajectory_characteristics$SecondaryJobs == 0,
    na.rm = TRUE
  ),
  "\n"
)


# ==================================================
# Check artistic practice
# ==================================================

cat(
  "\n=============================================\n",
  "ARTISTIC PRACTICE\n",
  "=============================================\n",
  sep = ""
)

cat(
  "\nMean weekly artistic hours per artist:\n"
)

print(
  summary(
    trajectory_characteristics$MeanArtisticHours
  )
)


# ==================================================
# Check final outcomes
# ==================================================

cat(
  "\n=============================================\n",
  "FINAL OUTCOMES\n",
  "=============================================\n",
  sep = ""
)

cat(
  "\nFinal EC:\n"
)

print(
  summary(
    trajectory_characteristics$FinalEC
  )
)

cat(
  "\nFinal SC:\n"
)

print(
  summary(
    trajectory_characteristics$FinalSC
  )
)

cat(
  "\nFinal SR:\n"
)

print(
  summary(
    trajectory_characteristics$FinalSR
  )
)


# ==================================================
# Save complete trajectory characteristics
# ==================================================

write.csv(
  trajectory_characteristics,
  "outputR/Sim1_tracev2_trajectory_characteristics_complete.csv",
  row.names = FALSE
)


# ==================================================
# Completion message
# ==================================================

cat(
  "\n=============================================\n",
  "TRACE v2 trajectory characteristics completed.\n",
  "Simulation length:",
  number_of_ticks,
  "weeks\n",
  "Final tick:",
  final_tick,
  "\n",
  "Trajectory characteristics saved.\n",
  "=============================================\n",
  sep = ""
)