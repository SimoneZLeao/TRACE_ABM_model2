# ============================================================
# SCRIPT 05
# TRACE v2 — Detailed Trajectory Profiles by k=5 Cluster
# ============================================================

library(tidyverse)


# ------------------------------------------------------------
# 1. FILE PATHS
# ------------------------------------------------------------

simulation_file <- "dataR/simulation1_data_tracev2.csv"

cluster_file <- "outputR/Sim1_tracev2_trajectory_clusters_k5.csv"

profile_output <-
  "outputR/Sim1_tracev2_cluster_trajectory_k5_profiles.csv"

summary_output <-
  "outputR/Sim1_tracev2_cluster_trajectory_k5_summary.csv"


# ------------------------------------------------------------
# 2. READ DATA
# ------------------------------------------------------------

simulation_data <- read_csv(
  simulation_file,
  show_col_types = FALSE
)

cluster_data <- read_csv(
  cluster_file,
  show_col_types = FALSE
)


# ------------------------------------------------------------
# 3. CHECK REQUIRED COLUMNS
# ------------------------------------------------------------

required_simulation_columns <- c(
  "Tick",
  "ArtistID",
  "EC",
  "SC",
  "SR",
  "State",
  "InvestmentDisposition",
  "SelfRealisationPropensity",
  "Investment",
  "RecognitionEvent",
  "SCGain",
  "EconomicEvent",
  "ECGain",
  "SRGain",
  "JobSeeker",
  "SecondaryJobType",
  "SecondaryJobHours",
  "SecondaryJobHourlyWage",
  "SecondaryJobDuration",
  "JobECGain",
  "ArtisticHours",
  "ExitCount",
  "ReturnCount",
  "SecondaryJobCount"
)

missing_simulation_columns <- setdiff(
  required_simulation_columns,
  names(simulation_data)
)

if (length(missing_simulation_columns) > 0) {
  stop(
    paste(
      "The following columns are missing from the simulation table:",
      paste(missing_simulation_columns, collapse = ", ")
    )
  )
}


if (!all(c("ArtistID", "Cluster") %in% names(cluster_data))) {
  stop(
    "The cluster file must contain both ArtistID and Cluster."
  )
}


# ------------------------------------------------------------
# 4. CLEAN VARIABLES
# ------------------------------------------------------------

simulation_data <- simulation_data %>%
  mutate(
    Tick = as.numeric(Tick),
    ArtistID = as.numeric(ArtistID),
    
    EC = as.numeric(EC),
    SC = as.numeric(SC),
    SR = as.numeric(SR),
    
    InvestmentDisposition = as.numeric(InvestmentDisposition),
    SelfRealisationPropensity =
      as.numeric(SelfRealisationPropensity),
    
    Investment = as.numeric(Investment),
    SCGain = as.numeric(SCGain),
    ECGain = as.numeric(ECGain),
    SRGain = as.numeric(SRGain),
    
    SecondaryJobHours =
      as.numeric(SecondaryJobHours),
    
    SecondaryJobHourlyWage =
      as.numeric(SecondaryJobHourlyWage),
    
    SecondaryJobDuration =
      as.numeric(SecondaryJobDuration),
    
    JobECGain =
      as.numeric(JobECGain),
    
    ArtisticHours =
      as.numeric(ArtisticHours),
    
    ExitCount =
      as.numeric(ExitCount),
    
    ReturnCount =
      as.numeric(ReturnCount),
    
    SecondaryJobCount =
      as.numeric(SecondaryJobCount),
    
    Active =
      State == "Active",
    
    Exited =
      State == "Exited",
    
    HasSecondaryJob =
      !is.na(SecondaryJobHours) &
      SecondaryJobHours > 0
  )


# ------------------------------------------------------------
# 5. SIMULATION INFORMATION
# ------------------------------------------------------------

simulation_length <-
  max(simulation_data$Tick, na.rm = TRUE) + 1

cat("\nSimulation length:", simulation_length, "ticks\n")

cat(
  "Number of artists:",
  n_distinct(simulation_data$ArtistID),
  "\n"
)


# ------------------------------------------------------------
# 6. ARTIST-LEVEL TRAJECTORY PROFILES
# ------------------------------------------------------------

artist_profiles <- simulation_data %>%
  group_by(ArtistID) %>%
  arrange(Tick, .by_group = TRUE) %>%
  summarise(
    
    # ========================================================
    # TRAJECTORY / TIME
    # ========================================================
    
    Time_Active =
      sum(Active, na.rm = TRUE),
    
    Time_Exited =
      sum(Exited, na.rm = TRUE),
    
    Proportion_Active =
      mean(Active, na.rm = TRUE),
    
    Proportion_Exited =
      mean(Exited, na.rm = TRUE),
    
    
    # ========================================================
    # EXIT AND RETURN
    # ========================================================
    
    Exit_Events =
      max(ExitCount, na.rm = TRUE),
    
    Return_Events =
      max(ReturnCount, na.rm = TRUE),
    
    First_Exit_Tick =
      if (any(Exited, na.rm = TRUE)) {
        min(Tick[Exited], na.rm = TRUE)
      } else {
        NA_real_
      },
    
    Final_State =
      last(State),
    
    
    # ========================================================
    # ECONOMIC CAPITAL
    # ========================================================
    
    Initial_EC =
      first(EC),
    
    Final_EC =
      last(EC),
    
    Mean_EC =
      mean(EC, na.rm = TRUE),
    
    Minimum_EC =
      min(EC, na.rm = TRUE),
    
    Maximum_EC =
      max(EC, na.rm = TRUE),
    
    SD_EC =
      sd(EC, na.rm = TRUE),
    
    Total_ECGain =
      sum(ECGain, na.rm = TRUE),
    
    Mean_ECGain =
      mean(ECGain, na.rm = TRUE),
    
    
    # ========================================================
    # INVESTMENT
    # ========================================================
    
    Mean_Investment_Disposition =
      mean(
        InvestmentDisposition,
        na.rm = TRUE
      ),
    
    Total_Investment =
      sum(Investment, na.rm = TRUE),
    
    Mean_Investment =
      mean(Investment, na.rm = TRUE),
    
    
    # ========================================================
    # SYMBOLIC CAPITAL
    # ========================================================
    
    Initial_SC =
      first(SC),
    
    Final_SC =
      last(SC),
    
    Mean_SC =
      mean(SC, na.rm = TRUE),
    
    Total_SC_Gain =
      sum(SCGain, na.rm = TRUE),
    
    Mean_SC_Gain =
      mean(SCGain, na.rm = TRUE),
    
    Recognition_Events =
      sum(
        RecognitionEvent == TRUE,
        na.rm = TRUE
      ),
    
    
    # ========================================================
    # SELF-REALISATION
    # ========================================================
    
    Initial_SR =
      first(SR),
    
    Final_SR =
      last(SR),
    
    Mean_SR =
      mean(SR, na.rm = TRUE),
    
    Total_SR_Gain =
      sum(SRGain, na.rm = TRUE),
    
    Mean_SR_Gain =
      mean(SRGain, na.rm = TRUE),
    
    Mean_SelfRealisation_Propensity =
      mean(
        SelfRealisationPropensity,
        na.rm = TRUE
      ),
    
    
    # ========================================================
    # ARTISTIC PRACTICE
    # ========================================================
    
    Total_Artistic_Hours =
      sum(ArtisticHours, na.rm = TRUE),
    
    Mean_Artistic_Hours =
      mean(ArtisticHours, na.rm = TRUE),
    
    Minimum_Artistic_Hours =
      min(ArtisticHours, na.rm = TRUE),
    
    Maximum_Artistic_Hours =
      max(ArtisticHours, na.rm = TRUE),
    
    SD_Artistic_Hours =
      sd(ArtisticHours, na.rm = TRUE),
    
    Artistic_Practice_Ticks =
      sum(
        ArtisticHours > 0,
        na.rm = TRUE
      ),
    
    Proportion_Max_Artistic_Hours =
      mean(
        ArtisticHours >= 40,
        na.rm = TRUE
      ),
    
    
    # ========================================================
    # SECONDARY EMPLOYMENT
    # ========================================================
    
    SecondaryJob_Episodes =
      max(
        SecondaryJobCount,
        na.rm = TRUE
      ),
    
    SecondaryJob_Ticks =
      sum(
        HasSecondaryJob,
        na.rm = TRUE
      ),
    
    Proportion_Ticks_With_SecondaryJob =
      mean(
        HasSecondaryJob,
        na.rm = TRUE
      ),
    
    Total_SecondaryJob_Hours =
      sum(
        SecondaryJobHours,
        na.rm = TRUE
      ),
    
    Mean_SecondaryJob_Hours_All_Ticks =
      mean(
        SecondaryJobHours,
        na.rm = TRUE
      ),
    
    Mean_SecondaryJob_Hours_When_Employed =
      ifelse(
        any(
          HasSecondaryJob,
          na.rm = TRUE
        ),
        mean(
          SecondaryJobHours[
            HasSecondaryJob
          ],
          na.rm = TRUE
        ),
        0
      ),
    
    Mean_SecondaryJob_Hourly_Wage =
      ifelse(
        any(
          HasSecondaryJob,
          na.rm = TRUE
        ),
        mean(
          SecondaryJobHourlyWage[
            HasSecondaryJob
          ],
          na.rm = TRUE
        ),
        0
      ),
    
    Total_Job_EC_Gain =
      sum(
        JobECGain,
        na.rm = TRUE
      ),
    
    Mean_Job_EC_Gain =
      ifelse(
        any(
          JobECGain > 0,
          na.rm = TRUE
        ),
        mean(
          JobECGain[
            JobECGain > 0
          ],
          na.rm = TRUE
        ),
        0
      ),
    
    .groups = "drop"
  )


# ------------------------------------------------------------
# 7. JOIN K=5 CLUSTER ASSIGNMENT
# ------------------------------------------------------------

cluster_membership <- cluster_data %>%
  select(
    ArtistID,
    Cluster
  ) %>%
  distinct()


artist_profiles <- artist_profiles %>%
  left_join(
    cluster_membership,
    by = "ArtistID"
  ) %>%
  relocate(
    Cluster,
    .after = ArtistID
  )


# ------------------------------------------------------------
# 8. CHECK CLUSTER ASSIGNMENTS
# ------------------------------------------------------------

if (any(is.na(artist_profiles$Cluster))) {
  
  missing_artists <-
    artist_profiles %>%
    filter(is.na(Cluster)) %>%
    pull(ArtistID)
  
  stop(
    paste(
      "Some artists do not have a cluster assignment:",
      paste(
        missing_artists,
        collapse = ", "
      )
    )
  )
}


cat("\nCluster membership:\n")

print(
  artist_profiles %>%
    count(Cluster) %>%
    mutate(
      Percentage =
        100 * n / sum(n)
    )
)


# ------------------------------------------------------------
# 9. SAVE ARTIST-LEVEL PROFILES
# ------------------------------------------------------------

write_csv(
  artist_profiles,
  profile_output
)

cat(
  "\nArtist-level profiles saved to:\n",
  profile_output,
  "\n"
)


# ============================================================
# 10. VARIABLES FOR CLUSTER SUMMARY
# ============================================================

summary_variables <- c(
  
  # Trajectory
  "Time_Active",
  "Time_Exited",
  "Proportion_Active",
  "Proportion_Exited",
  
  # Exit / return
  "Exit_Events",
  "Return_Events",
  "First_Exit_Tick",
  
  # Economic capital
  "Initial_EC",
  "Final_EC",
  "Mean_EC",
  "Minimum_EC",
  "Maximum_EC",
  "SD_EC",
  "Total_ECGain",
  "Mean_ECGain",
  
  # Investment
  "Mean_Investment_Disposition",
  "Total_Investment",
  "Mean_Investment",
  
  # Symbolic capital
  "Initial_SC",
  "Final_SC",
  "Mean_SC",
  "Total_SC_Gain",
  "Mean_SC_Gain",
  "Recognition_Events",
  
  # Self-realisation
  "Initial_SR",
  "Final_SR",
  "Mean_SR",
  "Total_SR_Gain",
  "Mean_SR_Gain",
  "Mean_SelfRealisation_Propensity",
  
  # Artistic practice
  "Total_Artistic_Hours",
  "Mean_Artistic_Hours",
  "Minimum_Artistic_Hours",
  "Maximum_Artistic_Hours",
  "SD_Artistic_Hours",
  "Artistic_Practice_Ticks",
  "Proportion_Max_Artistic_Hours",
  
  # Secondary employment
  "SecondaryJob_Episodes",
  "SecondaryJob_Ticks",
  "Proportion_Ticks_With_SecondaryJob",
  "Total_SecondaryJob_Hours",
  "Mean_SecondaryJob_Hours_All_Ticks",
  "Mean_SecondaryJob_Hours_When_Employed",
  "Mean_SecondaryJob_Hourly_Wage",
  "Total_Job_EC_Gain",
  "Mean_Job_EC_Gain"
)


# ============================================================
# 11. SAFE SUMMARY FUNCTION
# ============================================================

summarise_variable <- function(data, variable) {
  
  x <- data[[variable]]
  
  # If the entire variable is NA,
  # return NA rather than Inf / -Inf.
  
  if (all(is.na(x))) {
    
    return(
      tibble(
        Variable = variable,
        Mean = NA_real_,
        SD = NA_real_,
        Median = NA_real_,
        Minimum = NA_real_,
        Maximum = NA_real_
      )
    )
  }
  
  tibble(
    Variable = variable,
    
    Mean =
      mean(
        x,
        na.rm = TRUE
      ),
    
    SD =
      sd(
        x,
        na.rm = TRUE
      ),
    
    Median =
      median(
        x,
        na.rm = TRUE
      ),
    
    Minimum =
      min(
        x,
        na.rm = TRUE
      ),
    
    Maximum =
      max(
        x,
        na.rm = TRUE
      )
  )
}


# ============================================================
# 12. CREATE CLUSTER SUMMARY
# ============================================================

cluster_summary <- map_dfr(
  
  sort(
    unique(
      artist_profiles$Cluster
    )
  ),
  
  function(cluster_number) {
    
    cluster_data_temp <-
      artist_profiles %>%
      filter(
        Cluster == cluster_number
      )
    
    map_dfr(
      
      summary_variables,
      
      ~ summarise_variable(
        cluster_data_temp,
        .x
      )
      
    ) %>%
      
      mutate(
        Cluster = cluster_number,
        N = nrow(cluster_data_temp),
        .before = 1
      )
  }
)


# ============================================================
# 13. ADD CLUSTER SIZE AND PERCENTAGE
# ============================================================

cluster_sizes <- artist_profiles %>%
  count(
    Cluster,
    name = "Cluster_N"
  ) %>%
  mutate(
    Cluster_Percentage =
      100 * Cluster_N / sum(Cluster_N)
  )


cluster_summary <- cluster_summary %>%
  left_join(
    cluster_sizes,
    by = "Cluster"
  ) %>%
  relocate(
    Cluster_N,
    Cluster_Percentage,
    .after = N
  )


# ============================================================
# 14. SAVE CLUSTER SUMMARY
# ============================================================

write_csv(
  cluster_summary,
  summary_output
)

cat(
  "\nCluster summary saved to:\n",
  summary_output,
  "\n"
)


# ============================================================
# 15. PRINT SELECTED CHARACTERISTICS
# ============================================================

cat(
  "\n============================================\n"
)

cat(
  "SELECTED CLUSTER CHARACTERISTICS\n"
)

cat(
  "============================================\n\n"
)


selected_variables <- c(
  
  "Time_Active",
  "Time_Exited",
  "Exit_Events",
  "Return_Events",
  "SecondaryJob_Episodes",
  "SecondaryJob_Ticks",
  "Mean_SecondaryJob_Hours_When_Employed",
  "Mean_Artistic_Hours",
  "Mean_EC",
  "Final_EC",
  "Final_SC",
  "Final_SR"
)


print(
  
  cluster_summary %>%
    filter(
      Variable %in% selected_variables
    ) %>%
    select(
      Cluster,
      N,
      Cluster_Percentage,
      Variable,
      Mean,
      SD,
      Median
    ) %>%
    arrange(
      Cluster,
      match(
        Variable,
        selected_variables
      )
    ),
  
  n = Inf
)


# ============================================================
# 16. CHECK FOR INVALID SUMMARY VALUES
# ============================================================

invalid_values <- cluster_summary %>%
  filter(
    is.infinite(Mean) |
      is.infinite(SD) |
      is.infinite(Median) |
      is.infinite(Minimum) |
      is.infinite(Maximum)
  )


if (nrow(invalid_values) > 0) {
  
  warning(
    "Infinite values remain in the cluster summary."
  )
  
} else {
  
  cat(
    "\nNo infinite values detected in cluster summary.\n"
  )
}


# ============================================================
# 17. END
# ============================================================

cat(
  "\nScript 05 completed successfully.\n"
)