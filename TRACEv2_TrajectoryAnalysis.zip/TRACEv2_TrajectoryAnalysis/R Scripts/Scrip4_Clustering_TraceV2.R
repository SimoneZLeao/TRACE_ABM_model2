# ==================================================
# ArtistCareerTrajectory
# Script 04: Trajectory Clustering and k Comparison
# TRACE v2
# ==================================================


# ==================================================
# Load libraries
# ==================================================

library(readr)
library(dplyr)


# ==================================================
# Read OM distance matrix
# ==================================================

OM_distance <- readRDS(
  "outputR/Sim1_tracev2_OM_distance.rds"
)


# ==================================================
# Convert to distance object
# ==================================================

OM_dist <- as.dist(
  OM_distance
)


# ==================================================
# Check number of trajectories
# ==================================================

cat("\n")
cat("=============================================\n")
cat("OM / TRAJECTORY CHECK\n")
cat("=============================================\n")

cat(
  "Number of trajectories:",
  attr(OM_dist, "Size"),
  "\n"
)


# ==================================================
# Hierarchical clustering
# ==================================================

trajectory_hclust <- hclust(
  OM_dist,
  method = "ward.D2"
)


# ==================================================
# Plot dendrogram
# ==================================================

plot(
  trajectory_hclust,
  labels = FALSE,
  main = "Simulation 1 - Hierarchical clustering",
  xlab = "",
  sub = ""
)


# ==================================================
# Compare k = 4, 5 and 6
# ==================================================

cluster_comparison <- data.frame()


for (k in 4:6) {
  
  cluster_assignment <- cutree(
    trajectory_hclust,
    k = k
  )
  
  cluster_sizes <- table(
    cluster_assignment
  )
  
  temp <- data.frame(
    k = k,
    Cluster = as.numeric(
      names(cluster_sizes)
    ),
    N = as.numeric(
      cluster_sizes
    )
  )
  
  temp$Percentage <- (
    temp$N /
      sum(temp$N)
  ) * 100
  
  cluster_comparison <- bind_rows(
    cluster_comparison,
    temp
  )
  
}


# ==================================================
# Display cluster sizes
# ==================================================

cat("\n")
cat("=============================================\n")
cat("CLUSTER SIZES\n")
cat("=============================================\n")

print(
  cluster_comparison
)


# ==================================================
# Read trajectory characteristics
# ==================================================

trajectory_characteristics <- read_csv(
  "outputR/Sim1_tracev2_trajectory_characteristics_complete.csv",
  show_col_types = FALSE
)


# ==================================================
# Check trajectory characteristics
# ==================================================

cat("\n")
cat("=============================================\n")
cat("TRAJECTORY CHARACTERISTICS\n")
cat("=============================================\n")

print(
  names(trajectory_characteristics)
)


# ==================================================
# Select final solution: k = 5
# ==================================================

final_k <- 5

cluster_assignment <- cutree(
  trajectory_hclust,
  k = final_k
)


# ==================================================
# Create cluster membership table
# ==================================================

cluster_membership <- data.frame(
  
  ArtistID = as.numeric(
    names(cluster_assignment)
  ),
  
  Cluster = as.numeric(
    cluster_assignment
  )
  
)


# ==================================================
# Check cluster membership
# ==================================================

cat("\n")
cat("=============================================\n")
cat("SELECTED SOLUTION: k = 5\n")
cat("=============================================\n")

print(
  table(
    cluster_membership$Cluster
  )
)


# ==================================================
# Join cluster membership to trajectory data
# ==================================================

trajectory_clusters <- trajectory_characteristics %>%
  
  left_join(
    cluster_membership,
    by = "ArtistID"
  )


# ==================================================
# Check join
# ==================================================

cat("\n")
cat("=============================================\n")
cat("CLUSTER MEMBERSHIP CHECK\n")
cat("=============================================\n")

cat(
  "Number of artists:",
  nrow(trajectory_clusters),
  "\n"
)

cat(
  "Artists assigned to a cluster:",
  sum(!is.na(trajectory_clusters$Cluster)),
  "\n"
)

cat(
  "Artists without cluster:",
  sum(is.na(trajectory_clusters$Cluster)),
  "\n"
)


# ==================================================
# Cluster characteristics
# ==================================================

cluster_summary <- trajectory_clusters %>%
  
  group_by(
    Cluster
  ) %>%
  
  summarise(
    
    N = n(),
    
    Percentage = (
      n() /
        nrow(trajectory_clusters)
    ) * 100,
    
    # ----------------------------------------------
    # Trajectory characteristics
    # ----------------------------------------------
    
    MeanTransitions = mean(
      Transitions,
      na.rm = TRUE
    ),
    
    SDTransitions = sd(
      Transitions,
      na.rm = TRUE
    ),
    
    MeanTurbulence = mean(
      Turbulence,
      na.rm = TRUE
    ),
    
    SDTurbulence = sd(
      Turbulence,
      na.rm = TRUE
    ),
    
    MeanEntropy = mean(
      Entropy,
      na.rm = TRUE
    ),
    
    SDEntropy = sd(
      Entropy,
      na.rm = TRUE
    ),
    
    # ----------------------------------------------
    # Exit / return characteristics
    # ----------------------------------------------
    
    MeanFirstExitTick = mean(
      ExitTick,
      na.rm = TRUE
    ),
    
    SDFirstExitTick = sd(
      ExitTick,
      na.rm = TRUE
    ),
    
    MeanExitCount = mean(
      ExitCount,
      na.rm = TRUE
    ),
    
    SDExitCount = sd(
      ExitCount,
      na.rm = TRUE
    ),
    
    MeanReturnCount = mean(
      ReturnCount,
      na.rm = TRUE
    ),
    
    SDReturnCount = sd(
      ReturnCount,
      na.rm = TRUE
    ),
    
    ArtistsWithReturns = sum(
      ReturnCount > 0,
      na.rm = TRUE
    ),
    
    PercentageWithReturns = (
      sum(
        ReturnCount > 0,
        na.rm = TRUE
      ) /
        n()
    ) * 100,
    
    # ----------------------------------------------
    # Secondary employment
    # ----------------------------------------------
    
    MeanSecondaryJobs = mean(
      SecondaryJobs,
      na.rm = TRUE
    ),
    
    SDSecondaryJobs = sd(
      SecondaryJobs,
      na.rm = TRUE
    ),
    
    ArtistsWithSecondaryJobs = sum(
      SecondaryJobs > 0,
      na.rm = TRUE
    ),
    
    PercentageWithSecondaryJobs = (
      sum(
        SecondaryJobs > 0,
        na.rm = TRUE
      ) /
        n()
    ) * 100,
    
    MeanSecondaryJobHours = mean(
      MeanSecondaryJobHours,
      na.rm = TRUE
    ),
    
    SDSecondaryJobHours = sd(
      MeanSecondaryJobHours,
      na.rm = TRUE
    ),
    
    # ----------------------------------------------
    # Artistic practice
    # ----------------------------------------------
    
    MeanArtisticHours = mean(
      MeanArtisticHours,
      na.rm = TRUE
    ),
    
    SDArtisticHours = sd(
      MeanArtisticHours,
      na.rm = TRUE
    ),
    
    # ----------------------------------------------
    # Final outcomes
    # ----------------------------------------------
    
    MeanFinalEC = mean(
      FinalEC,
      na.rm = TRUE
    ),
    
    SDFinalEC = sd(
      FinalEC,
      na.rm = TRUE
    ),
    
    MeanFinalSC = mean(
      FinalSC,
      na.rm = TRUE
    ),
    
    SDFinalSC = sd(
      FinalSC,
      na.rm = TRUE
    ),
    
    MeanFinalSR = mean(
      FinalSR,
      na.rm = TRUE
    ),
    
    SDFinalSR = sd(
      FinalSR,
      na.rm = TRUE
    ),
    
    Survivors = sum(
      FinalSurvivor,
      na.rm = TRUE
    ),
    
    PercentageSurvivors = (
      sum(
        FinalSurvivor,
        na.rm = TRUE
      ) /
        n()
    ) * 100,
    
    .groups = "drop"
    
  )


# ==================================================
# Display cluster characteristics
# ==================================================

cat("\n")
cat("=============================================\n")
cat("CLUSTER CHARACTERISTICS - k = 5\n")
cat("=============================================\n")

print(
  cluster_summary
)


# ==================================================
# Calculate within-cluster OM distances
# ==================================================

within_cluster_results <- data.frame()


for (cluster_number in sort(
  unique(cluster_membership$Cluster)
)) {
  
  members <- cluster_membership$ArtistID[
    cluster_membership$Cluster ==
      cluster_number
  ]
  
  cluster_distance_matrix <- OM_distance[
    as.character(members),
    as.character(members),
    drop = FALSE
  ]
  
  upper_distances <- cluster_distance_matrix[
    upper.tri(
      cluster_distance_matrix
    )
  ]
  
  mean_distance <- mean(
    upper_distances,
    na.rm = TRUE
  )
  
  temp <- data.frame(
    Cluster = cluster_number,
    MeanWithinClusterOM = mean_distance
  )
  
  within_cluster_results <- bind_rows(
    within_cluster_results,
    temp
  )
  
}


# ==================================================
# Display within-cluster OM distances
# ==================================================

cat("\n")
cat("=============================================\n")
cat("WITHIN-CLUSTER OM DISTANCES - k = 5\n")
cat("=============================================\n")

print(
  within_cluster_results
)


# ==================================================
# Add OM distances to cluster summary
# ==================================================

cluster_summary <- cluster_summary %>%
  
  left_join(
    within_cluster_results,
    by = "Cluster"
  )


# ==================================================
# Save cluster membership
# ==================================================

write.csv(
  
  trajectory_clusters,
  
  "outputR/Sim1_tracev2_trajectory_clusters_k5.csv",
  
  row.names = FALSE
  
)


# ==================================================
# Save cluster summary
# ==================================================

write.csv(
  
  cluster_summary,
  
  "outputR/Sim1_tracev2_cluster_summary_k5.csv",
  
  row.names = FALSE
  
)


# ==================================================
# Save k comparison
# ==================================================

write.csv(
  
  cluster_comparison,
  
  "outputR/Sim1_tracev2_cluster_comparison_k4_k5_k6.csv",
  
  row.names = FALSE
  
)


# ==================================================
# Save cluster membership only
# ==================================================

write.csv(
  
  cluster_membership,
  
  "outputR/Sim1_tracev2_cluster_membership_k5.csv",
  
  row.names = FALSE
  
)


# ==================================================
# Final message
# ==================================================

cat("\n")
cat("=============================================\n")
cat("TRACE v2 CLUSTERING COMPLETED\n")
cat("=============================================\n")

cat(
  "Selected clustering solution: k = 5\n"
)

cat(
  "Clustering basis: OM trajectory distance only\n"
)

cat(
  "Additional variables: descriptive characteristics only\n"
)

cat(
  "Outputs saved to outputR/\n"
)

cat("=============================================\n")